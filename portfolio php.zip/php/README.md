# Portfolio Website - Nabil Bright Yinpugat

A modern, responsive portfolio website built with PHP, HTML, CSS, and JavaScript.

## Features

- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Modern UI**: Clean and professional design with smooth animations
- **Contact Form**: Functional contact form with email integration
- **Smooth Scrolling**: Enhanced navigation experience
- **Mobile Menu**: Hamburger menu for mobile devices
- **All CV Sections**: 
  - Professional Summary
  - Education Timeline
  - Work Experience
  - Technical Skills
  - Languages
  - Contact Information

## File Structure

```
php/
├── index.php          # Main portfolio page
├── contact.php        # Contact form handler
├── README.md          # This file
└── assets/
    ├── css/
    │   └── style.css  # All styling
    └── js/
        └── script.js  # JavaScript functionality
```

## Setup Instructions

### 1. Local Development (XAMPP/WAMP/MAMP)

1. **Install a local server**:
   - Download and install [XAMPP](https://www.apachefriends.org/) (Windows/Mac/Linux)
   - Or [WAMP](https://www.wampserver.com/) (Windows)
   - Or [MAMP](https://www.mamp.info/) (Mac)

2. **Place files in server directory**:
   - Copy all files to `htdocs` folder (XAMPP) or `www` folder (WAMP/MAMP)
   - Example: `C:\xampp\htdocs\portfolio\`

3. **Start the server**:
   - Open XAMPP/WAMP/MAMP Control Panel
   - Start Apache server

4. **Access the website**:
   - Open browser and go to: `http://localhost/portfolio/`
   - Or: `http://localhost/portfolio/index.php`

### 2. Online Hosting

1. **Upload files to your web hosting**:
   - Use FTP client (FileZilla, WinSCP) or hosting control panel
   - Upload all files to `public_html` or `www` directory

2. **Configure email** (for contact form):
   - Most hosting providers have PHP mail() enabled by default
   - For better email delivery, consider using SMTP (requires additional configuration)

3. **Access your website**:
   - Visit your domain: `https://yourdomain.com`

## Customization

### Updating Personal Information

Edit `index.php` to update:
- Name, contact details
- Professional summary
- Education details
- Work experience
- Skills and languages

### Changing Colors

Edit `assets/css/style.css` and modify the CSS variables at the top:

```css
:root {
    --primary-color: #2563eb;    /* Main brand color */
    --secondary-color: #1e40af;  /* Secondary color */
    --accent-color: #3b82f6;      /* Accent color */
}
```

### Contact Form Email

The contact form sends emails to: `brightnabil558@gmail.com`

To change this, edit `contact.php` line 23:
```php
$to = "your-email@example.com";
```

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Technologies Used

- **PHP**: Server-side scripting
- **HTML5**: Structure
- **CSS3**: Styling with modern features
- **JavaScript**: Interactive functionality
- **Font Awesome**: Icons

## Notes

- The contact form requires PHP mail() function to be enabled on your server
- For production, consider using SMTP for more reliable email delivery
- All personal information is currently in `index.php` - you can extract it to a separate config file if needed

## License

This portfolio is created for personal use. Feel free to customize it for your own portfolio!

---

**Created for**: Nabil Bright Yinpugat  
**Date**: 2025

