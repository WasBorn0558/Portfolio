<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nabil Bright Yinpugat - Portfolio</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Notification Messages -->
    <div id="notificationContainer"></div>
    <script>
    // Only show notification if it's a fresh form submission (not a refresh)
    (function() {
        const urlParams = new URLSearchParams(window.location.search);
        const success = urlParams.get('success');
        const error = urlParams.get('error');
        
        if (success === '1' || error) {
            const notificationKey = success ? 'formSuccess' : 'formError';
            const alreadyShown = sessionStorage.getItem(notificationKey);
            
            if (!alreadyShown) {
                const container = document.getElementById('notificationContainer');
                if (success === '1') {
                    container.innerHTML = `
                        <div class="notification notification-success">
                            <i class="fas fa-check-circle"></i>
                            <span>Thank you for your message! I'll get back to you soon.</span>
                            <button class="notification-close">&times;</button>
                        </div>
                    `;
                } else if (error) {
                    const errorMessage = decodeURIComponent(error);
                    container.innerHTML = `
                        <div class="notification notification-error">
                            <i class="fas fa-exclamation-circle"></i>
                            <span>${errorMessage}</span>
                            <button class="notification-close">&times;</button>
                        </div>
                    `;
                }
                
                // Mark as shown
                sessionStorage.setItem(notificationKey, 'true');
                setTimeout(() => {
                    sessionStorage.removeItem(notificationKey);
                }, 5000);
            }
        }
    })();
    </script>
    
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="#home" class="nav-brand">NB</a>
            <ul class="nav-menu">
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="#education">Education</a></li>
                <li><a href="#experience">Experience</a></li>
                <li><a href="#projects">Projects</a></li>
                <li><a href="#skills">Skills</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
            <div class="nav-actions">
                <button class="theme-toggle" id="themeToggle" aria-label="Toggle dark mode">
                    <i class="fas fa-moon" id="themeIcon"></i>
                </button>
                <div class="hamburger">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="container">
            <div class="hero-content">
                <div class="hero-avatar">
                    <div class="avatar-container">
                        <img src="assets/images/profile.jpg" alt="Nabil Bright Yinpugat" class="avatar-img" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                        <div class="avatar-placeholder">
                            <i class="fas fa-user"></i>
                        </div>
                    </div>
                </div>
                <h1 class="hero-title">Nabil Bright Yinpugat</h1>
                <p class="hero-subtitle">Computer Science & Engineering Graduate</p>
                <p class="hero-description">IT Support Specialist | System Administrator | IoT Developer</p>
                <div class="hero-social">
                    <a href="mailto:brightnabil558@gmail.com" class="social-link" title="Email">
                        <i class="fas fa-envelope"></i>
                    </a>
                    <a href="tel:+233558434362" class="social-link" title="Phone">
                        <i class="fas fa-phone"></i>
                    </a>
                    <a href="https://wa.me/233558434362" class="social-link" title="WhatsApp" target="_blank">
                        <i class="fab fa-whatsapp"></i>
                    </a>
                    <a href="https://linkedin.com/in/nabil-bright-yinpugat" class="social-link" title="LinkedIn" target="_blank">
                        <i class="fab fa-linkedin"></i>
                    </a>
                    <a href="https://github.com/nabilbright" class="social-link" title="GitHub" target="_blank">
                        <i class="fab fa-github"></i>
                    </a>
                </div>
                <div class="hero-buttons">
                    <a href="#contact" class="btn btn-primary">Get In Touch</a>
                    <a href="#about" class="btn btn-secondary">Learn More</a>
                    <a href="download_cv.php" class="btn btn-outline" target="_blank">
                        <i class="fas fa-download"></i> Download CV
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <h2 class="section-title">About Me</h2>
            <div class="about-content">
                <div class="about-text">
                    <h3>Professional Summary</h3>
                    <p>Recent Computer Science and Engineering graduate with strong interest in both computer hardware, software troubleshooting and operating system installation. Skilled in diagnosing and resolving technical issues, setting up and maintaining computer systems, and ensuring smooth hardware and software integration.</p>
                    <p>Possess a basic foundation in networking, programming and system administration, complemented by hands-on experience in maintaining and repairing IT equipment. Motivated to apply problem-solving abilities and technical expertise in an entry-level IT support, system administration or engineering role.</p>
                    
                    <div class="contact-info">
                        <div class="info-item">
                            <i class="fas fa-map-marker-alt"></i>
                            <span>Kumasi Kodie, Ghana</span>
                        </div>
                        <div class="info-item">
                            <i class="fas fa-phone"></i>
                            <span>0558434362 / 0509890787</span>
                        </div>
                        <div class="info-item">
                            <i class="fas fa-envelope"></i>
                            <a href="mailto:brightnabil558@gmail.com">brightnabil558@gmail.com</a>
                        </div>
                        <div class="info-item">
                            <i class="fas fa-map-pin"></i>
                            <span>Digital Address: AF-0037-7745</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Education Section -->
    <section id="education" class="education">
        <div class="container">
            <h2 class="section-title">Education</h2>
            <div class="timeline">
                <div class="timeline-item">
                    <div class="timeline-date">2021 - 2025</div>
                    <div class="timeline-content">
                        <h3>BSc. Computer Science and Engineering</h3>
                        <h4>University of Mines and Technology</h4>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-date">2017 - 2020</div>
                    <div class="timeline-content">
                        <h3>WASSCE</h3>
                        <h4>Jacobu Senior High Technical School</h4>
                    </div>
                </div>
                <div class="timeline-item">
                    <div class="timeline-date">2009 - 2017</div>
                    <div class="timeline-content">
                        <h3>BECE</h3>
                        <h4>Sacred Heart Roman Catholic School</h4>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Experience Section -->
    <section id="experience" class="experience">
        <div class="container">
            <h2 class="section-title">Work Experience</h2>
            <div class="experience-grid">
                <div class="experience-card">
                    <div class="experience-header">
                        <h3>Self-taught Operating Systems Specialist & IT Troubleshooting Expert</h3>
                        <span class="experience-date">2020 - Present</span>
                    </div>
                    <ul class="experience-duties">
                        <li><strong>Multi-Platform OS Installation & Configuration:</strong> Successfully installed, configured, and optimized various operating systems including Windows (7, 10, 11), Linux distributions (Ubuntu, Fedora, Debian), and macOS across diverse hardware configurations, ensuring seamless compatibility and optimal performance</li>
                        <li><strong>Comprehensive Hardware & Software Diagnostics:</strong> Developed expertise in identifying and resolving complex system faults through systematic troubleshooting methodologies, including BIOS/UEFI configuration, driver compatibility issues, and hardware component failures</li>
                        <li><strong>System Performance Optimization:</strong> Implemented performance tuning techniques such as disk defragmentation, registry optimization, memory management, and startup program optimization, resulting in significant improvements in system responsiveness and boot times</li>
                        <li><strong>Data Recovery & Backup Solutions:</strong> Created and implemented robust backup strategies, performed data recovery operations for critical files, and set up automated backup systems to prevent data loss</li>
                        <li><strong>Cross-Platform Compatibility Testing:</strong> Conducted extensive compatibility testing of software applications and hardware peripherals across different operating systems, documenting findings and recommending optimal configurations</li>
                    </ul>
                </div>

                <div class="experience-card">
                    <div class="experience-header">
                        <h3>Student Hardware and Software Developer</h3>
                        <span class="experience-date">2025</span>
                        <span class="experience-company">University of Mines and Technology</span>
                    </div>
                    <ul class="experience-duties">
                        <li><strong>IoT Energy Monitoring System Development:</strong> Designed and developed a comprehensive Internet of Things (IoT) based energy monitoring system using Python, embedded systems, and web technologies to track real-time power consumption of individual household appliances</li>
                        <li><strong>Web Dashboard Implementation:</strong> Created an intuitive, responsive web dashboard using HTML, CSS, JavaScript, and PHP that provides real-time data visualization, historical consumption analysis, and cost estimation features for electricity usage</li>
                        <li><strong>Sensor Integration & Data Collection:</strong> Integrated multiple current and voltage sensors with microcontrollers (Arduino/ESP32) to accurately measure and transmit power consumption data to a centralized database</li>
                        <li><strong>Data Analysis & Reporting:</strong> Implemented data analytics algorithms to generate detailed consumption reports, identify energy-intensive appliances, and provide actionable insights for energy conservation</li>
                        <li><strong>System Architecture & Scalability:</strong> Architected a scalable system capable of monitoring multiple appliances simultaneously, with the ability to expand to commercial and industrial settings for comprehensive energy management</li>
                    </ul>
                </div>

                <div class="experience-card">
                    <div class="experience-header">
                        <h3>IT Support Intern</h3>
                        <span class="experience-date">September 2024 - December 2024</span>
                        <span class="experience-company">Ghana Publishing Company Limited</span>
                    </div>
                    <ul class="experience-duties">
                        <li><strong>Technical Issue Documentation & Resolution:</strong> Systematically documented and tracked technical issues using ticketing systems, ensuring proper categorization, prioritization, and escalation to senior technical team members when necessary, maintaining a 95% first-response resolution rate</li>
                        <li><strong>Network Infrastructure Management:</strong> Monitored, diagnosed, and resolved network-related issues including connectivity problems, bandwidth optimization, IP configuration conflicts, and router/switch malfunctions, reducing network downtime by 40%</li>
                        <li><strong>System Performance Maintenance:</strong> Performed regular system maintenance tasks including software updates, security patches, antivirus scans, and system optimizations to ensure optimal performance and security of company IT infrastructure</li>
                        <li><strong>User Support & Training:</strong> Provided technical support to staff members, assisting with software installation, troubleshooting common IT issues, and conducting basic training sessions on company systems and best practices</li>
                        <li><strong>Collaborative Problem Solving:</strong> Collaborated effectively with cross-functional technical teams on complex escalation cases, contributing to root cause analysis and implementing long-term solutions to prevent recurring issues</li>
                        <li><strong>IT Asset Management:</strong> Maintained accurate inventory of IT equipment, tracked hardware lifecycles, and assisted in procurement processes for new equipment and software licenses</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Projects Section -->
    <section id="projects" class="projects">
        <div class="container">
            <h2 class="section-title">Featured Projects</h2>
            <div class="projects-grid">
                <div class="project-card">
                    <div class="project-icon">
                        <i class="fas fa-bolt"></i>
                    </div>
                    <h3>IoT Energy Monitoring System</h3>
                    <p>Built an Internet of Things (IoT) based energy monitoring system with a web dashboard to monitor the power consumption of individual appliances in households or any place that uses electricity.</p>
                    <div class="project-tech">
                        <span class="tech-tag">IoT</span>
                        <span class="tech-tag">Web Dashboard</span>
                        <span class="tech-tag">Energy Monitoring</span>
                        <span class="tech-tag">Python</span>
                    </div>
                    <div class="project-links">
                        <a href="mailto:brightnabil558@gmail.com?subject=Inquiry about IoT Energy Monitoring System" class="project-link">
                            <i class="fas fa-envelope"></i> Learn More
                        </a>
                    </div>
                </div>

                <div class="project-card">
                    <div class="project-icon">
                        <i class="fas fa-laptop-code"></i>
                    </div>
                    <h3>Operating System Installation & Troubleshooting</h3>
                    <p>Self-taught expertise in installing and troubleshooting various operating systems across different hardware configurations, ensuring optimal system performance and compatibility.</p>
                    <div class="project-tech">
                        <span class="tech-tag">OS Installation</span>
                        <span class="tech-tag">Hardware Troubleshooting</span>
                        <span class="tech-tag">System Maintenance</span>
                    </div>
                    <div class="project-links">
                        <a href="#experience" class="project-link">
                            <i class="fas fa-arrow-right"></i> View Details
                        </a>
                    </div>
                </div>

                <div class="project-card">
                    <div class="project-icon">
                        <i class="fas fa-network-wired"></i>
                    </div>
                    <h3>Network Diagnostics & Maintenance</h3>
                    <p>Experience in monitoring, diagnosing, and resolving network-related issues to maintain uptime and system performance, with hands-on experience from internship at Ghana Publishing Company Limited.</p>
                    <div class="project-tech">
                        <span class="tech-tag">Networking</span>
                        <span class="tech-tag">Diagnostics</span>
                        <span class="tech-tag">System Performance</span>
                    </div>
                    <div class="project-links">
                        <a href="#experience" class="project-link">
                            <i class="fas fa-arrow-right"></i> View Details
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Skills Section -->
    <section id="skills" class="skills">
        <div class="container">
            <h2 class="section-title">Technical Skills</h2>
            <div class="skills-grid">
                <div class="skill-category">
                    <h3><i class="fas fa-code"></i> Programming & Web</h3>
                    <div class="skill-tags">
                        <span class="skill-tag">Python</span>
                        <span class="skill-tag">HTML</span>
                        <span class="skill-tag">CSS</span>
                        <span class="skill-tag">PHP</span>
                    </div>
                </div>
                <div class="skill-category">
                    <h3><i class="fas fa-tools"></i> Software & Tools</h3>
                    <div class="skill-tags">
                        <span class="skill-tag">Microsoft Office</span>
                        <span class="skill-tag">Operating Systems</span>
                        <span class="skill-tag">System Administration</span>
                    </div>
                </div>
                <div class="skill-category">
                    <h3><i class="fas fa-network-wired"></i> IT & Networking</h3>
                    <div class="skill-tags">
                        <span class="skill-tag">Hardware Troubleshooting</span>
                        <span class="skill-tag">Software Troubleshooting</span>
                        <span class="skill-tag">Network Diagnostics</span>
                        <span class="skill-tag">IoT Development</span>
                    </div>
                </div>
                <div class="skill-category">
                    <h3><i class="fas fa-users"></i> Soft Skills</h3>
                    <div class="skill-tags">
                        <span class="skill-tag">Teamwork & Collaboration</span>
                        <span class="skill-tag">Time Management</span>
                        <span class="skill-tag">Adaptability</span>
                        <span class="skill-tag">Problem-solving</span>
                    </div>
                </div>
            </div>

            <div class="languages-section">
                <h3><i class="fas fa-language"></i> Languages</h3>
                <div class="language-list">
                    <div class="language-item">
                        <span class="language-name">English</span>
                        <div class="language-bar">
                            <div class="language-progress" style="width: 100%"></div>
                        </div>
                    </div>
                    <div class="language-item">
                        <span class="language-name">Twi</span>
                        <div class="language-bar">
                            <div class="language-progress" style="width: 100%"></div>
                        </div>
                    </div>
                    <div class="language-item">
                        <span class="language-name">Frafra (Talin)</span>
                        <div class="language-bar">
                            <div class="language-progress" style="width: 100%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
            <h2 class="section-title">Get In Touch</h2>
            <div class="contact-content">
                <div class="contact-info-section">
                    <h3>Contact Information</h3>
                    <div class="contact-item">
                        <i class="fas fa-phone"></i>
                        <div>
                            <strong>Phone</strong>
                            <p>0558434362 / 0509890787</p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-envelope"></i>
                        <div>
                            <strong>Email</strong>
                            <p><a href="mailto:brightnabil558@gmail.com">brightnabil558@gmail.com</a></p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <div>
                            <strong>Location</strong>
                            <p>Kumasi Kodie, Ghana</p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-map-pin"></i>
                        <div>
                            <strong>Digital Address</strong>
                            <p>AF-0037-7745</p>
                        </div>
                    </div>
                </div>
                <div class="contact-form-section">
                    <h3>Send a Message</h3>
                    <form action="contact.php" method="POST" class="contact-form">
                        <div class="form-group">
                            <input type="text" name="name" placeholder="Your Name" required>
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" placeholder="Your Email" required>
                        </div>
                        <div class="form-group">
                            <input type="text" name="subject" placeholder="Subject" required>
                        </div>
                        <div class="form-group">
                            <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Nabil Bright Yinpugat</h3>
                    <p>Computer Science & Engineering Graduate</p>
                    <p>IT Support Specialist | System Administrator | IoT Developer</p>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="#home">Home</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="#projects">Projects</a></li>
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contact</h4>
                    <p><i class="fas fa-envelope"></i> <a href="mailto:brightnabil558@gmail.com">brightnabil558@gmail.com</a></p>
                    <p><i class="fas fa-phone"></i> 0558434362 / 0509890787</p>
                    <p><i class="fas fa-map-marker-alt"></i> Kumasi Kodie, Ghana</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Nabil Bright Yinpugat. All rights reserved.</p>
                <p class="footer-note">References available upon request</p>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <button class="back-to-top" id="backToTop" aria-label="Back to top">
        <i class="fas fa-arrow-up"></i>
    </button>

    <script src="assets/js/script.js"></script>
</body>
</html>

