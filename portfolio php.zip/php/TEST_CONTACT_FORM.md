# How to Test the Contact Form

## Quick Test Steps

### 1. **Start XAMPP**
   - Open XAMPP Control Panel
   - Make sure **Apache** is running (green)

### 2. **Open Your Portfolio**
   - Go to: `http://localhost/portfolio/` or `http://localhost/portfolio/index.php`
   - Scroll down to the **Contact** section

### 3. **Fill Out the Form**
   - **Name**: Enter your name (e.g., "Test User")
   - **Email**: Enter a valid email (e.g., "test@example.com")
   - **Subject**: Enter a subject (e.g., "Test Message")
   - **Message**: Enter a test message (e.g., "This is a test message from my portfolio")

### 4. **Submit the Form**
   - Click the **"Send Message"** button
   - You should see a success notification appear in the top-right corner

### 5. **Check the Result**
   - **Success**: Green notification saying "Thank you for your message!"
   - **Error**: Red notification with error details

---

## Important: Email on Localhost (XAMPP)

⚠️ **Note**: On localhost (XAMPP), PHP's `mail()` function **may not work** by default because:
- XAMPP doesn't have a mail server configured
- Emails won't actually be sent from localhost

### What Happens:
- The form will **still work** and show success/error messages
- But the email **won't actually be sent** to `brightnabil558@gmail.com`
- This is normal for localhost testing

### Solutions:

#### Option 1: Test on Live Server (Recommended)
- Upload your portfolio to a web hosting service
- Most hosting providers have mail() enabled
- The form will work and send real emails

#### Option 2: Configure XAMPP Mail (Advanced)
- Requires setting up a mail server or SMTP
- More complex setup

#### Option 3: Use a Test Script
- I've created `test_contact.php` to help you verify the form works
- See below for instructions

---

## Testing with test_contact.php

I've created a test file to help you verify everything works:

1. **Open**: `http://localhost/portfolio/test_contact.php`
2. **Fill the form** and submit
3. **Check the output** - it will show you:
   - If the form data was received
   - If validation passed
   - If email would be sent (simulated)
   - Any errors

---

## What to Check

✅ **Form Validation**:
- Try submitting with empty fields - should show errors
- Try invalid email format - should show error
- Fill all fields correctly - should show success

✅ **Success Message**:
- After successful submission, you should see a green notification
- The form should redirect back to the page

✅ **Error Handling**:
- Empty fields should show specific error messages
- Invalid email should be caught

---

## Testing on Live Server

When you upload to a real web host:

1. **Upload all files** to your hosting
2. **Test the form** - it should send real emails
3. **Check your email** (`brightnabil558@gmail.com`) for:
   - Subject: "Portfolio Contact: [Your Subject]"
   - Message with name, email, and message content

---

## Troubleshooting

### Form doesn't submit:
- Check if Apache is running
- Check browser console for errors
- Make sure `contact.php` is in the same folder as `index.php`

### No success message:
- Check if PHP is working (look for PHP errors)
- Check browser's Network tab for form submission

### Email not received (on live server):
- Check spam folder
- Verify email address in `contact.php` (line 31)
- Some hosts require SMTP configuration instead of mail()

---

## Need Help?

If you encounter issues:
1. Check the browser console (F12) for errors
2. Check XAMPP error logs
3. Verify all files are in the correct locations

