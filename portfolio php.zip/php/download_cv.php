<?php
// CV Download Handler
// Check if PDF file exists
$pdfFile = 'assets/cv/Nabil_Bright_Yinpugat_CV.pdf';

if (file_exists($pdfFile)) {
    // Serve PDF file
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="Nabil_Bright_Yinpugat_CV.pdf"');
    header('Content-Length: ' . filesize($pdfFile));
    header('Content-Transfer-Encoding: binary');
    header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
    header('Pragma: public');
    readfile($pdfFile);
    exit;
} else {
    // Generate PDF from HTML using html2pdf.js library
    ob_start();
    include 'generate_cv.php';
    $html = ob_get_clean();
    
    // Add PDF generation script
    $pdfScript = '
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <script>
    window.onload = function() {
        // Hide any print buttons or instructions
        var body = document.body;
        
        // Create loading message
        var loading = document.createElement("div");
        loading.id = "pdfLoading";
        loading.style.cssText = "position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:white;padding:30px 50px;border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,0.3);z-index:10000;text-align:center;";
        loading.innerHTML = "<h2 style=\'color:#2563eb;margin-bottom:15px;\'>Generating PDF...</h2><p>Please wait while your CV is being prepared for download.</p><div style=\'margin-top:20px;\'><div style=\'border:4px solid #f3f3f3;border-top:4px solid #2563eb;border-radius:50%;width:40px;height:40px;animation:spin 1s linear infinite;margin:0 auto;\'></div></div>";
        document.body.appendChild(loading);
        
        // Add spinner animation
        var style = document.createElement("style");
        style.textContent = "@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }";
        document.head.appendChild(style);
        
        // Generate PDF
        var element = document.body;
        var opt = {
            margin: [10, 10, 10, 10],
            filename: "Nabil_Bright_Yinpugat_CV.pdf",
            image: { type: "jpeg", quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true },
            jsPDF: { unit: "mm", format: "a4", orientation: "portrait" }
        };
        
        html2pdf().set(opt).from(element).save().then(function() {
            // Remove loading message
            document.getElementById("pdfLoading").remove();
            
            // Show success message briefly
            var success = document.createElement("div");
            success.style.cssText = "position:fixed;top:20px;right:20px;background:#10b981;color:white;padding:15px 25px;border-radius:8px;box-shadow:0 4px 6px rgba(0,0,0,0.3);z-index:10001;";
            success.innerHTML = "✅ PDF downloaded successfully!";
            document.body.appendChild(success);
            
            setTimeout(function() {
                success.style.opacity = "0";
                success.style.transition = "opacity 0.5s";
                setTimeout(function() {
                    success.remove();
                    // Close window after download (optional)
                    // window.close();
                }, 500);
            }, 2000);
        }).catch(function(error) {
            // Remove loading message
            document.getElementById("pdfLoading").remove();
            
            // Show error and fallback to print
            var errorMsg = document.createElement("div");
            errorMsg.style.cssText = "position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:white;padding:30px;border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,0.3);z-index:10001;text-align:center;max-width:500px;";
            errorMsg.innerHTML = "<h3 style=\'color:#ef4444;margin-bottom:15px;\'>PDF Generation Failed</h3><p>Please use the print button below to save as PDF.</p><button onclick=\'window.print()\' style=\'margin-top:20px;padding:12px 30px;background:#2563eb;color:white;border:none;border-radius:8px;cursor:pointer;font-size:16px;font-weight:bold;\'>🖨️ Print / Save as PDF</button>";
            document.body.appendChild(errorMsg);
        });
    };
    </script>';
    
    $html = str_replace('</body>', $pdfScript . '</body>', $html);
    
    header('Content-Type: text/html; charset=UTF-8');
    echo $html;
    exit;
}
?>

