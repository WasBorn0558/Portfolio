<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nabil Bright Yinpugat - CV</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            padding: 40px;
            max-width: 900px;
            margin: 0 auto;
            background: #fff;
        }
        .header {
            text-align: center;
            border-bottom: 3px solid #2563eb;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        .header h1 {
            font-size: 2.5em;
            color: #2563eb;
            margin-bottom: 10px;
        }
        .header p {
            font-size: 1.1em;
            color: #666;
            margin: 5px 0;
        }
        .contact-info {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 20px;
            margin-top: 15px;
            font-size: 0.95em;
        }
        .contact-info span {
            color: #555;
        }
        .section {
            margin: 30px 0;
            page-break-inside: avoid;
        }
        .section h2 {
            color: #2563eb;
            font-size: 1.8em;
            border-bottom: 2px solid #2563eb;
            padding-bottom: 8px;
            margin-bottom: 15px;
        }
        .section h3 {
            color: #1e40af;
            font-size: 1.3em;
            margin-top: 15px;
            margin-bottom: 8px;
        }
        .section h4 {
            color: #666;
            font-size: 1.1em;
            font-weight: normal;
            margin-bottom: 10px;
        }
        .section p {
            margin-bottom: 10px;
            text-align: justify;
        }
        .section ul {
            margin-left: 20px;
            margin-bottom: 15px;
        }
        .section li {
            margin-bottom: 8px;
        }
        .date {
            color: #2563eb;
            font-weight: 600;
            margin-bottom: 5px;
        }
        .skills-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 15px;
        }
        .skill-category {
            background: #f9fafb;
            padding: 15px;
            border-left: 4px solid #2563eb;
        }
        .skill-category h4 {
            color: #2563eb;
            margin-bottom: 10px;
        }
        .skill-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        .skill-tag {
            background: white;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 0.9em;
            border: 1px solid #e5e7eb;
        }
        .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
            color: #666;
            font-size: 0.9em;
        }
        @media print {
            body {
                padding: 20px;
            }
            .section {
                page-break-inside: avoid;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>NABIL, BRIGHT YINPUGAT</h1>
        <p>Computer Science & Engineering Graduate</p>
        <p>IT Support Specialist | System Administrator | IoT Developer</p>
        <div class="contact-info">
            <span><strong>Location:</strong> Kumasi Kodie, Ghana</span>
            <span><strong>Mobile:</strong> 0558434362 / 0509890787</span>
            <span><strong>Email:</strong> brightnabil558@gmail.com</span>
            <span><strong>Digital Address:</strong> AF-0037-7745</span>
        </div>
    </div>

    <div class="section">
        <h2>PROFESSIONAL SUMMARY</h2>
        <p>Recent Computer Science and Engineering graduate with strong interest in both computer hardware, software troubleshooting and operating system installation. Skilled in diagnosing and resolving technical issues, setting up and maintaining computer systems, and ensuring smooth hardware and software integration.</p>
        <p>Possess a basic foundation in networking, programming and system administration, complemented by hands-on experience in maintaining and repairing IT equipment. Motivated to apply problem-solving abilities and technical expertise in an entry-level IT support, system administration or engineering role.</p>
    </div>

    <div class="section">
        <h2>EDUCATION</h2>
        <div>
            <div class="date">2021 - 2025</div>
            <h3>BSc. Computer Science and Engineering</h3>
            <h4>University of Mines and Technology</h4>
        </div>
        <div style="margin-top: 20px;">
            <div class="date">2017 - 2020</div>
            <h3>WASSCE</h3>
            <h4>Jacobu Senior High Technical School</h4>
        </div>
        <div style="margin-top: 20px;">
            <div class="date">2009 - 2017</div>
            <h3>BECE</h3>
            <h4>Sacred Heart Roman Catholic School</h4>
        </div>
    </div>

    <div class="section">
        <h2>WORK EXPERIENCE</h2>
        <div>
            <h3>Self-taught Operating Systems Specialist & IT Troubleshooting Expert</h3>
            <div class="date">2020 – Present</div>
            <ul>
                <li><strong>Multi-Platform OS Installation & Configuration:</strong> Successfully installed, configured, and optimized various operating systems including Windows (7, 10, 11), Linux distributions (Ubuntu, Fedora, Debian), and macOS across diverse hardware configurations, ensuring seamless compatibility and optimal performance</li>
                <li><strong>Comprehensive Hardware & Software Diagnostics:</strong> Developed expertise in identifying and resolving complex system faults through systematic troubleshooting methodologies, including BIOS/UEFI configuration, driver compatibility issues, and hardware component failures</li>
                <li><strong>System Performance Optimization:</strong> Implemented performance tuning techniques such as disk defragmentation, registry optimization, memory management, and startup program optimization, resulting in significant improvements in system responsiveness and boot times</li>
                <li><strong>Data Recovery & Backup Solutions:</strong> Created and implemented robust backup strategies, performed data recovery operations for critical files, and set up automated backup systems to prevent data loss</li>
                <li><strong>Cross-Platform Compatibility Testing:</strong> Conducted extensive compatibility testing of software applications and hardware peripherals across different operating systems, documenting findings and recommending optimal configurations</li>
            </ul>
        </div>
        <div style="margin-top: 20px;">
            <h3>Student Hardware and Software Developer</h3>
            <div class="date">2025</div>
            <h4>University of Mines and Technology</h4>
            <ul>
                <li><strong>IoT Energy Monitoring System Development:</strong> Designed and developed a comprehensive Internet of Things (IoT) based energy monitoring system using Python, embedded systems, and web technologies to track real-time power consumption of individual household appliances</li>
                <li><strong>Web Dashboard Implementation:</strong> Created an intuitive, responsive web dashboard using HTML, CSS, JavaScript, and PHP that provides real-time data visualization, historical consumption analysis, and cost estimation features for electricity usage</li>
                <li><strong>Sensor Integration & Data Collection:</strong> Integrated multiple current and voltage sensors with microcontrollers (Arduino/ESP32) to accurately measure and transmit power consumption data to a centralized database</li>
                <li><strong>Data Analysis & Reporting:</strong> Implemented data analytics algorithms to generate detailed consumption reports, identify energy-intensive appliances, and provide actionable insights for energy conservation</li>
                <li><strong>System Architecture & Scalability:</strong> Architected a scalable system capable of monitoring multiple appliances simultaneously, with the ability to expand to commercial and industrial settings for comprehensive energy management</li>
            </ul>
        </div>
        <div style="margin-top: 20px;">
            <h3>IT Support Intern</h3>
            <div class="date">September 2024 - December 2024</div>
            <h4>Ghana Publishing Company Limited</h4>
            <ul>
                <li><strong>Technical Issue Documentation & Resolution:</strong> Systematically documented and tracked technical issues using ticketing systems, ensuring proper categorization, prioritization, and escalation to senior technical team members when necessary, maintaining a 95% first-response resolution rate</li>
                <li><strong>Network Infrastructure Management:</strong> Monitored, diagnosed, and resolved network-related issues including connectivity problems, bandwidth optimization, IP configuration conflicts, and router/switch malfunctions, reducing network downtime by 40%</li>
                <li><strong>System Performance Maintenance:</strong> Performed regular system maintenance tasks including software updates, security patches, antivirus scans, and system optimizations to ensure optimal performance and security of company IT infrastructure</li>
                <li><strong>User Support & Training:</strong> Provided technical support to staff members, assisting with software installation, troubleshooting common IT issues, and conducting basic training sessions on company systems and best practices</li>
                <li><strong>Collaborative Problem Solving:</strong> Collaborated effectively with cross-functional technical teams on complex escalation cases, contributing to root cause analysis and implementing long-term solutions to prevent recurring issues</li>
                <li><strong>IT Asset Management:</strong> Maintained accurate inventory of IT equipment, tracked hardware lifecycles, and assisted in procurement processes for new equipment and software licenses</li>
            </ul>
        </div>
    </div>

    <div class="section">
        <h2>TECHNICAL SKILLS</h2>
        <div class="skills-grid">
            <div class="skill-category">
                <h4>Programming & Web</h4>
                <div class="skill-tags">
                    <span class="skill-tag">Python</span>
                    <span class="skill-tag">HTML</span>
                    <span class="skill-tag">CSS</span>
                    <span class="skill-tag">PHP</span>
                </div>
            </div>
            <div class="skill-category">
                <h4>Software & Tools</h4>
                <div class="skill-tags">
                    <span class="skill-tag">Microsoft Office</span>
                    <span class="skill-tag">Operating Systems</span>
                    <span class="skill-tag">System Administration</span>
                </div>
            </div>
            <div class="skill-category">
                <h4>IT & Networking</h4>
                <div class="skill-tags">
                    <span class="skill-tag">Hardware Troubleshooting</span>
                    <span class="skill-tag">Software Troubleshooting</span>
                    <span class="skill-tag">Network Diagnostics</span>
                    <span class="skill-tag">IoT Development</span>
                </div>
            </div>
            <div class="skill-category">
                <h4>Soft Skills</h4>
                <div class="skill-tags">
                    <span class="skill-tag">Teamwork & Collaboration</span>
                    <span class="skill-tag">Time Management</span>
                    <span class="skill-tag">Adaptability</span>
                    <span class="skill-tag">Problem-solving</span>
                </div>
            </div>
        </div>
    </div>

    <div class="section">
        <h2>LANGUAGES</h2>
        <ul>
            <li><strong>English Language</strong> - Fluent</li>
            <li><strong>Twi</strong> - Fluent</li>
            <li><strong>Frafra (Talin)</strong> - Fluent</li>
        </ul>
    </div>

    <div class="footer">
        <p>References available upon request</p>
        <p>Generated: <?php echo date('F Y'); ?></p>
    </div>
</body>
</html>

