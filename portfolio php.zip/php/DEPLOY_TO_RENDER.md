# How to Host Your Portfolio on Render

## Step-by-Step Guide to Deploy on Render

### Prerequisites
- GitHub account (free)
- Render account (free tier available)
- Your portfolio files ready

---

## Step 1: Prepare Your Files for GitHub

### 1.1 Create a `.gitignore` file
Create a file named `.gitignore` in your project folder:

```
# Logs
*.log
contact_log.txt

# Environment variables
.env

# Cache
*.cache

# OS files
.DS_Store
Thumbs.db

# IDE files
.vscode/
.idea/
*.swp
*.swo

# XAMPP specific
xampp/
```

### 1.2 Create a `render.yaml` file (optional but recommended)
Create a file named `render.yaml` in your project root:

```yaml
services:
  - type: web
    name: nabil-portfolio
    env: php
    buildCommand: ""
    startCommand: php -S 0.0.0.0:$PORT
    envVars:
      - key: PHP_VERSION
        value: 8.2
```

---

## Step 2: Push Your Code to GitHub

### 2.1 Initialize Git (if not already done)
Open terminal in your project folder and run:

```bash
git init
git add .
git commit -m "Initial commit - Portfolio website"
```

### 2.2 Create GitHub Repository
1. Go to [GitHub.com](https://github.com)
2. Click the "+" icon → "New repository"
3. Name it: `portfolio` or `nabil-portfolio`
4. Choose "Public" (free) or "Private"
5. Don't initialize with README
6. Click "Create repository"

### 2.3 Push to GitHub
```bash
git remote add origin https://github.com/YOUR_USERNAME/portfolio.git
git branch -M main
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username.

---

## Step 3: Deploy on Render

### 3.1 Create Render Account
1. Go to [render.com](https://render.com)
2. Click "Get Started for Free"
3. Sign up with GitHub (recommended) or email

### 3.2 Create New Web Service
1. Click "New +" → "Web Service"
2. Connect your GitHub account (if not already connected)
3. Select your repository (`portfolio` or `nabil-portfolio`)
4. Click "Connect"

### 3.3 Configure Your Service

**Basic Settings:**
- **Name:** `nabil-portfolio` (or your preferred name)
- **Environment:** `PHP`
- **Region:** Choose closest to you (e.g., `Oregon (US West)`)
- **Branch:** `main` (or `master`)

**Build Settings:**
- **Build Command:** Leave empty (or use: `composer install` if you have dependencies)
- **Start Command:** `php -S 0.0.0.0:$PORT`

**Advanced Settings (optional):**
- **Auto-Deploy:** Yes (automatically deploys on git push)
- **Health Check Path:** `/` or `/index.php`

### 3.4 Environment Variables (if needed)
If your contact form needs email configuration:
- Click "Advanced"
- Add environment variables if needed
- For email, you might need SMTP settings

### 3.5 Deploy
1. Click "Create Web Service"
2. Render will start building your site
3. Wait 2-5 minutes for deployment
4. Your site will be live at: `https://nabil-portfolio.onrender.com` (or your chosen name)

---

## Step 4: Configure Contact Form Email

### 4.1 Update contact.php for Production
Your contact form may need SMTP configuration for production. Update `contact.php`:

```php
<?php
// For Render/production, you might need to configure SMTP
// Option 1: Use PHP mail() - works on Render
// Option 2: Use a service like Mailgun, SendGrid, or SMTP

// Example with SMTP (requires PHPMailer library):
// You can install PHPMailer via Composer
```

### 4.2 Recommended: Use a Third-Party Email Service
For reliable email delivery on Render, consider:
- **SendGrid** (free tier: 100 emails/day)
- **Mailgun** (free tier: 5,000 emails/month)
- **SMTP** (Gmail, Outlook, etc.)

---

## Step 5: Custom Domain (Optional)

### 5.1 Add Custom Domain on Render
1. Go to your service settings
2. Click "Custom Domains"
3. Add your domain (e.g., `www.yourname.com`)
4. Follow DNS configuration instructions

### 5.2 Update DNS
Update your domain's DNS records:
- **Type:** CNAME
- **Name:** www
- **Value:** `nabil-portfolio.onrender.com`

---

## Step 6: Post-Deployment Checklist

- [ ] Test your website: Visit your Render URL
- [ ] Check all pages load correctly
- [ ] Test contact form (may need email configuration)
- [ ] Test CV download functionality
- [ ] Verify dark mode works
- [ ] Check mobile responsiveness
- [ ] Test all navigation links
- [ ] Verify profile picture loads

---

## Important Notes for Render

### File Paths
- Make sure all file paths use relative paths (they already do)
- Images: `assets/images/profile.jpg`
- CSS: `assets/css/style.css`
- JS: `assets/js/script.js`

### PHP Version
- Render supports PHP 7.4, 8.0, 8.1, 8.2
- Default is usually PHP 8.2 (recommended)

### Static Files
- Render serves static files automatically
- No special configuration needed for CSS/JS/images

### Database (if needed later)
- Render offers PostgreSQL and MySQL
- Free tier available for databases
- Not needed for your current portfolio

---

## Troubleshooting

### Issue: Site shows 404 or doesn't load
**Solution:**
- Check that `index.php` is in the root directory
- Verify start command is: `php -S 0.0.0.0:$PORT`
- Check build logs in Render dashboard

### Issue: Contact form doesn't send emails
**Solution:**
- PHP mail() may not work on Render
- Use a third-party email service (SendGrid, Mailgun)
- Or configure SMTP in contact.php

### Issue: Images/CSS not loading
**Solution:**
- Check file paths are correct (relative paths)
- Verify files are committed to GitHub
- Check browser console for 404 errors

### Issue: CV download doesn't work
**Solution:**
- Verify `download_cv.php` and `generate_cv.php` are in root
- Check file permissions
- Test the PDF generation library loads correctly

---

## Render Free Tier Limits

- **750 hours/month** (enough for 24/7 hosting)
- **100 GB bandwidth/month**
- **Auto-sleep** after 15 minutes of inactivity (wakes on next request)
- **Free SSL certificate** included
- **Custom domains** supported

---

## Quick Start Commands

```bash
# 1. Initialize Git
git init

# 2. Add all files
git add .

# 3. Commit
git commit -m "Portfolio ready for deployment"

# 4. Add remote (replace with your repo URL)
git remote add origin https://github.com/YOUR_USERNAME/portfolio.git

# 5. Push to GitHub
git push -u origin main
```

Then follow steps 3-6 above to deploy on Render.

---

## Support Resources

- **Render Documentation:** https://render.com/docs
- **Render PHP Guide:** https://render.com/docs/deploy-php
- **Render Community:** https://community.render.com

---

**Good luck with your deployment! Your portfolio will be live in minutes! 🚀**

