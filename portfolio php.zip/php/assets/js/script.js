// Mobile Navigation Toggle
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');

hamburger.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    hamburger.classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-menu a').forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        hamburger.classList.remove('active');
    });
});

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const hash = this.getAttribute('href');
        const target = document.querySelector(hash);
        if (target) {
            // Store hash for page load detection
            if (hash && hash !== '#home') {
                sessionStorage.setItem('hashScroll', hash);
            }
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add active class to navigation on scroll
window.addEventListener('scroll', () => {
    const sections = document.querySelectorAll('section[id]');
    const scrollY = window.pageYOffset;

    sections.forEach(current => {
        const sectionHeight = current.offsetHeight;
        const sectionTop = current.offsetTop - 100;
        const sectionId = current.getAttribute('id');

        if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
            document.querySelectorAll('.nav-menu a').forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${sectionId}`) {
                    link.classList.add('active');
                }
            });
        }
    });
});

// Animate progress bars on scroll
const observerOptions = {
    threshold: 0.5
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const progressBars = entry.target.querySelectorAll('.language-progress');
            progressBars.forEach(bar => {
                const width = bar.style.width;
                bar.style.width = '0';
                setTimeout(() => {
                    bar.style.width = width;
                }, 100);
            });
        }
    });
}, observerOptions);

const skillsSection = document.querySelector('.languages-section');
if (skillsSection) {
    observer.observe(skillsSection);
}

// Notification close functionality
document.querySelectorAll('.notification-close').forEach(button => {
    button.addEventListener('click', function() {
        this.closest('.notification').style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            this.closest('.notification').remove();
        }, 300);
    });
});

// Auto-hide notifications after 5 seconds
const notifications = document.querySelectorAll('.notification');
if (notifications.length > 0) {
    setTimeout(() => {
        notifications.forEach(notification => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                notification.remove();
            }, 300);
        });
    }, 5000);
}

// Dark Mode Toggle
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');
const html = document.documentElement;

// Check for saved theme preference or default to light mode
const currentTheme = localStorage.getItem('theme') || 'light';
html.setAttribute('data-theme', currentTheme);
updateThemeIcon(currentTheme);

themeToggle.addEventListener('click', () => {
    const currentTheme = html.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    html.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    updateThemeIcon(newTheme);
});

function updateThemeIcon(theme) {
    if (themeIcon) {
        if (theme === 'dark') {
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-sun');
        } else {
            themeIcon.classList.remove('fa-sun');
            themeIcon.classList.add('fa-moon');
        }
    }
}

// Back to Top Button
const backToTopButton = document.getElementById('backToTop');

window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
        backToTopButton.classList.add('visible');
    } else {
        backToTopButton.classList.remove('visible');
    }
});

backToTopButton.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

// Handle contact form success - scroll to contact section and clear form
window.addEventListener('DOMContentLoaded', () => {
    // Check if we have a success or error message
    const urlParams = new URLSearchParams(window.location.search);
    const success = urlParams.get('success');
    const error = urlParams.get('error');
    
    // Check if we've already processed this notification (prevents showing on refresh)
    const notificationKey = success ? 'formSuccess' : (error ? 'formError' : null);
    const alreadyShown = sessionStorage.getItem(notificationKey);
    
    // Clean up URL IMMEDIATELY to prevent showing on refresh
    if (success || error) {
        const cleanUrl = window.location.pathname + (window.location.hash || '');
        window.history.replaceState({}, '', cleanUrl);
    }
    
    // Only process if this is a fresh form submission (not a refresh)
    if ((success === '1' || error) && !alreadyShown) {
        // Mark as shown
        if (notificationKey) {
            sessionStorage.setItem(notificationKey, 'true');
            // Clear after 5 seconds so it can show again on next submission
            setTimeout(() => {
                sessionStorage.removeItem(notificationKey);
            }, 5000);
        }
        
        // Scroll to contact section only if we're near the top
        if (window.scrollY < 100) {
            setTimeout(() => {
                const contactSection = document.getElementById('contact');
                if (contactSection) {
                    contactSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }, 300);
        }
        
        // Clear form if success
        if (success === '1') {
            const form = document.querySelector('.contact-form');
            if (form) {
                setTimeout(() => {
                    form.reset();
                }, 500);
            }
        }
    } else if (alreadyShown) {
        // If already shown, hide the notification immediately
        const notifications = document.querySelectorAll('.notification');
        notifications.forEach(notification => {
            notification.style.display = 'none';
        });
    }
    
    // Only scroll to hash if it's from a navigation link click (not refresh)
    if (window.location.hash && window.location.hash !== '#home' && !success && !error) {
        const hashFromClick = sessionStorage.getItem('hashScroll');
        if (hashFromClick === window.location.hash) {
            setTimeout(() => {
                const target = document.querySelector(window.location.hash);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }, 100);
            sessionStorage.removeItem('hashScroll');
        }
    }
});


