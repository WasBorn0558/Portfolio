<?php
// Contact form handler
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data
    $name = htmlspecialchars(trim($_POST['name'] ?? ''));
    $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
    $subject = htmlspecialchars(trim($_POST['subject'] ?? ''));
    $message = htmlspecialchars(trim($_POST['message'] ?? ''));
    
    // Validation
    $errors = [];
    
    if (empty($name)) {
        $errors[] = "Name is required";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email is required";
    }
    
    if (empty($subject)) {
        $errors[] = "Subject is required";
    }
    
    if (empty($message)) {
        $errors[] = "Message is required";
    }
    
    // If no errors, send email
    if (empty($errors)) {
        $to = "brightnabil558@gmail.com";
        $email_subject = "Portfolio Contact: " . $subject;
        $email_body = "You have received a new message from your portfolio contact form.\n\n";
        $email_body .= "Name: " . $name . "\n";
        $email_body .= "Email: " . $email . "\n\n";
        $email_body .= "Message:\n" . $message . "\n";
        
        // Enhanced email headers
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $headers .= "From: Portfolio Contact Form <noreply@portfolio.com>\r\n";
        $headers .= "Reply-To: " . $email . "\r\n";
        $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
        $headers .= "X-Priority: 1\r\n";
        
        // Attempt to send email
        // Note: On localhost (XAMPP), mail() may return false even if configured
        // For testing purposes, we'll show success if validation passes
        $mail_sent = @mail($to, $email_subject, $email_body, $headers);
        
        // Check if we're on localhost
        $is_localhost = in_array($_SERVER['HTTP_HOST'], ['localhost', '127.0.0.1']) || 
                        strpos($_SERVER['HTTP_HOST'], 'localhost') !== false;
        
        if ($mail_sent || $is_localhost) {
            // On localhost, always show success (can't actually send emails)
            // On live server, only show success if mail() returns true
            $success = true;
            $message_sent = "Thank you for your message! I'll get back to you soon.";
            
            // Log the email data for testing (only on localhost)
            if ($is_localhost) {
                // Save to a log file for testing
                $log_entry = date('Y-m-d H:i:s') . " - Contact Form Submission\n";
                $log_entry .= "Name: $name\n";
                $log_entry .= "Email: $email\n";
                $log_entry .= "Subject: $subject\n";
                $log_entry .= "Message: $message\n";
                $log_entry .= "---\n\n";
                @file_put_contents('contact_log.txt', $log_entry, FILE_APPEND);
            }
        } else {
            $errors[] = "Sorry, there was an error sending your message. Please try again later.";
        }
    }
}

// Redirect back to index with message
$redirect_url = "index.php";
if (isset($success) && $success) {
    $redirect_url .= "?success=1#contact";
} elseif (!empty($errors)) {
    $redirect_url .= "?error=" . urlencode(implode(", ", $errors)) . "#contact";
}
header("Location: " . $redirect_url);
exit;
?>

