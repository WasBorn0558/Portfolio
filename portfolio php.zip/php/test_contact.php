<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Contact Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2563eb;
            margin-bottom: 20px;
        }
        .test-section {
            margin: 20px 0;
            padding: 15px;
            background: #f9fafb;
            border-left: 4px solid #2563eb;
            border-radius: 5px;
        }
        .success {
            background: #d1fae5;
            border-color: #10b981;
            color: #065f46;
        }
        .error {
            background: #fee2e2;
            border-color: #ef4444;
            color: #991b1b;
        }
        .info {
            background: #dbeafe;
            border-color: #3b82f6;
            color: #1e40af;
        }
        form {
            margin-top: 30px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #374151;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            border: 2px solid #e5e7eb;
            border-radius: 5px;
            font-size: 14px;
            box-sizing: border-box;
        }
        input:focus, textarea:focus {
            outline: none;
            border-color: #2563eb;
        }
        button {
            background: #2563eb;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
        }
        button:hover {
            background: #1e40af;
        }
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #2563eb;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🧪 Contact Form Test Page</h1>
        
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            echo '<div class="test-section success">';
            echo '<h2>✅ Form Submitted Successfully!</h2>';
            echo '</div>';
            
            // Get form data
            $name = htmlspecialchars(trim($_POST['name'] ?? ''));
            $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
            $subject = htmlspecialchars(trim($_POST['subject'] ?? ''));
            $message = htmlspecialchars(trim($_POST['message'] ?? ''));
            
            // Validation
            $errors = [];
            
            echo '<div class="test-section info">';
            echo '<h3>📋 Form Data Received:</h3>';
            echo '<p><strong>Name:</strong> ' . ($name ?: '<em>Empty</em>') . '</p>';
            echo '<p><strong>Email:</strong> ' . ($email ?: '<em>Empty</em>') . '</p>';
            echo '<p><strong>Subject:</strong> ' . ($subject ?: '<em>Empty</em>') . '</p>';
            echo '<p><strong>Message:</strong> ' . ($message ?: '<em>Empty</em>') . '</p>';
            echo '</div>';
            
            // Validate
            if (empty($name)) {
                $errors[] = "Name is required";
            }
            
            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Valid email is required";
            }
            
            if (empty($subject)) {
                $errors[] = "Subject is required";
            }
            
            if (empty($message)) {
                $errors[] = "Message is required";
            }
            
            if (empty($errors)) {
                echo '<div class="test-section success">';
                echo '<h3>✅ Validation Passed!</h3>';
                echo '<p>All fields are valid and ready to send.</p>';
                echo '</div>';
                
                // Check if mail function exists
                echo '<div class="test-section info">';
                echo '<h3>📧 Email Configuration:</h3>';
                if (function_exists('mail')) {
                    echo '<p>✅ PHP mail() function is available</p>';
                    
                    // Simulate email (don't actually send on localhost)
                    $to = "brightnabil558@gmail.com";
                    $email_subject = "Portfolio Contact: " . $subject;
                    $email_body = "You have received a new message from your portfolio contact form.\n\n";
                    $email_body .= "Name: " . $name . "\n";
                    $email_body .= "Email: " . $email . "\n\n";
                    $email_body .= "Message:\n" . $message . "\n";
                    
                    echo '<p><strong>To:</strong> ' . $to . '</p>';
                    echo '<p><strong>Subject:</strong> ' . $email_subject . '</p>';
                    echo '<p><strong>Message Preview:</strong></p>';
                    echo '<pre style="background: white; padding: 10px; border-radius: 5px;">' . htmlspecialchars($email_body) . '</pre>';
                    
                    // Note about localhost
                    echo '<p style="margin-top: 15px; padding: 10px; background: #fef3c7; border-left: 4px solid #f59e0b; border-radius: 5px;">';
                    echo '⚠️ <strong>Note:</strong> On localhost (XAMPP), emails won\'t actually be sent. ';
                    echo 'Upload to a live server to send real emails.';
                    echo '</p>';
                } else {
                    echo '<p>❌ PHP mail() function is not available</p>';
                }
                echo '</div>';
            } else {
                echo '<div class="test-section error">';
                echo '<h3>❌ Validation Errors:</h3>';
                echo '<ul>';
                foreach ($errors as $error) {
                    echo '<li>' . htmlspecialchars($error) . '</li>';
                }
                echo '</ul>';
                echo '</div>';
            }
            
            echo '<a href="test_contact.php" class="back-link">← Test Again</a>';
        } else {
            ?>
            <div class="test-section info">
                <h3>📝 Instructions:</h3>
                <ol>
                    <li>Fill out the form below</li>
                    <li>Click "Test Submit"</li>
                    <li>Check the results to see if everything works</li>
                </ol>
                <p><strong>Note:</strong> This test page shows you what data is received and validates it, but won't send actual emails on localhost.</p>
            </div>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="name">Name *</label>
                    <input type="text" id="name" name="name" placeholder="Enter your name" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" id="email" name="email" placeholder="your.email@example.com" required>
                </div>
                
                <div class="form-group">
                    <label for="subject">Subject *</label>
                    <input type="text" id="subject" name="subject" placeholder="Message subject" required>
                </div>
                
                <div class="form-group">
                    <label for="message">Message *</label>
                    <textarea id="message" name="message" rows="5" placeholder="Your message here..." required></textarea>
                </div>
                
                <button type="submit">Test Submit</button>
            </form>
            
            <a href="index.php" class="back-link">← Back to Portfolio</a>
            <?php
        }
        ?>
    </div>
</body>
</html>

